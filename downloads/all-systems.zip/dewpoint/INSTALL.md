# Install Dewpoint

Free during launch. Fonts load from Google Fonts: Figtree, JetBrains Mono.

## 1. Add the folder
Copy the `dewpoint/` folder into your project (for example `public/dewpoint/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="dewpoint/tokens.css">
  <link rel="stylesheet" href="dewpoint/components/bundle.css">
  <script defer src="dewpoint/components/bundle.js"></script>
</head>
<body>
  <a class="dp-btn dp-btn--primary" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Dewpoint.init(); Dewpoint.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Dewpoint.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `dp-`. Open `dewpoint/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./dewpoint/tokens.css";
import "./dewpoint/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./dewpoint/components/bundle.js").then(() => { window.Dewpoint?.init?.(); window.Dewpoint?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="dp-btn dp-btn--primary" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "surface": "var(--surface)",
        "surface-container": "var(--surface-container)",
        "surface-container-high": "var(--surface-container-high)",
        "surface-container-higher": "var(--surface-container-higher)",
        "surface-container-highest": "var(--surface-container-highest)",
        "on-surface": "var(--on-surface)",
        "on-surface-variant": "var(--on-surface-variant)",
        "outline-hairline": "var(--outline-hairline)",
        "outline": "var(--outline)",
        "outline-strong": "var(--outline-strong)",
        "primary": "var(--primary)",
        "on-primary": "var(--on-primary)",
        "primary-hover": "var(--primary-hover)",
        "secondary-fill": "var(--secondary-fill)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Dewpoint" design system in ./dewpoint.
1. Read dewpoint/README.md (brand book), then dewpoint/tokens.json, then components/<Name>/README.md for every component you use.
2. Link dewpoint/tokens.css, dewpoint/components/bundle.css and dewpoint/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix dp- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from dewpoint/assets. For any new picture follow dewpoint/imagery.md (it has a prompt and a negative prompt).
5. Follow dewpoint/motion.md and honour prefers-reduced-motion. Check dewpoint/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Dewpoint.initExtras()` after the markup exists (again after you add markup later).
