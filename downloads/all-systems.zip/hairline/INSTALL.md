# Install Hairline

Free during launch. Fonts load from Google Fonts: Albert Sans.

## 1. Add the folder
Copy the `hairline/` folder into your project (for example `public/hairline/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="hairline/tokens.css">
  <link rel="stylesheet" href="hairline/components/bundle.css">
  <script defer src="hairline/components/bundle.js"></script>
</head>
<body>
  <a class="hl-btn hl-btn--primary" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Hairline.init(); Hairline.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Hairline.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `hl-`. Open `hairline/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./hairline/tokens.css";
import "./hairline/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./hairline/components/bundle.js").then(() => { window.Hairline?.init?.(); window.Hairline?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="hl-btn hl-btn--primary" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "neutral-20": "var(--neutral-20)",
        "neutral-50": "var(--neutral-50)",
        "neutral-100": "var(--neutral-100)",
        "neutral-200": "var(--neutral-200)",
        "neutral-300": "var(--neutral-300)",
        "neutral-400": "var(--neutral-400)",
        "neutral-500": "var(--neutral-500)",
        "neutral-600": "var(--neutral-600)",
        "neutral-700": "var(--neutral-700)",
        "neutral-800": "var(--neutral-800)",
        "neutral-900": "var(--neutral-900)",
        "neutral-950": "var(--neutral-950)",
        "neutral-1000": "var(--neutral-1000)",
        "surface": "var(--surface)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Hairline" design system in ./hairline.
1. Read hairline/README.md (brand book), then hairline/tokens.json, then components/<Name>/README.md for every component you use.
2. Link hairline/tokens.css, hairline/components/bundle.css and hairline/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix hl- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from hairline/assets. For any new picture follow hairline/imagery.md (it has a prompt and a negative prompt).
5. Follow hairline/motion.md and honour prefers-reduced-motion. Check hairline/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Hairline.initExtras()` after the markup exists (again after you add markup later).
