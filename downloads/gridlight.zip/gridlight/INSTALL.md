# Install Gridlight

Free during launch. Fonts load from Google Fonts: Inter, DM Mono, Source Serif 4.

## 1. Add the folder
Copy the `gridlight/` folder into your project (for example `public/gridlight/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="gridlight/tokens.css">
  <link rel="stylesheet" href="gridlight/components/bundle.css">
  <script defer src="gridlight/components/bundle.js"></script>
</head>
<body>
  <a class="gl-btn" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Gridlight.init(); Gridlight.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Gridlight.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `gl-`. Open `gridlight/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./gridlight/tokens.css";
import "./gridlight/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="dark">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./gridlight/components/bundle.js").then(() => { window.Gridlight?.init?.(); window.Gridlight?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="gl-btn" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "surface": "var(--surface)",
        "surface-raised": "var(--surface-raised)",
        "surface-container": "var(--surface-container)",
        "surface-container-high": "var(--surface-container-high)",
        "fill-secondary": "var(--fill-secondary)",
        "fill-secondary-hover": "var(--fill-secondary-hover)",
        "outline-hairline": "var(--outline-hairline)",
        "outline": "var(--outline)",
        "outline-strong": "var(--outline-strong)",
        "on-surface": "var(--on-surface)",
        "on-surface-variant": "var(--on-surface-variant)",
        "on-surface-muted": "var(--on-surface-muted)",
        "on-surface-disabled": "var(--on-surface-disabled)",
        "primary": "var(--primary)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Gridlight" design system in ./gridlight.
1. Read gridlight/README.md (brand book), then gridlight/tokens.json, then components/<Name>/README.md for every component you use.
2. Link gridlight/tokens.css, gridlight/components/bundle.css and gridlight/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix gl- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from gridlight/assets. For any new picture follow gridlight/imagery.md (it has a prompt and a negative prompt).
5. Follow gridlight/motion.md and honour prefers-reduced-motion. Check gridlight/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Gridlight.initExtras()` after the markup exists (again after you add markup later).
