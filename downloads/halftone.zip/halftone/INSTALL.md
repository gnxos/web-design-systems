# Install Halftone

Free during launch. Fonts load from Google Fonts: Hanken Grotesk, Geist Mono.

## 1. Add the folder
Copy the `halftone/` folder into your project (for example `public/halftone/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="halftone/tokens.css">
  <link rel="stylesheet" href="halftone/components/bundle.css">
  <script defer src="halftone/components/bundle.js"></script>
</head>
<body>
  <a class="ht-btn ht-btn--pink" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Halftone.init(); Halftone.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Halftone.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `ht-`. Open `halftone/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./halftone/tokens.css";
import "./halftone/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./halftone/components/bundle.js").then(() => { window.Halftone?.init?.(); window.Halftone?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="ht-btn ht-btn--pink" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "canvas": "var(--canvas)",
        "surface": "var(--surface)",
        "surface-strong": "var(--surface-strong)",
        "line": "var(--line)",
        "ink": "var(--ink)",
        "ink-secondary": "var(--ink-secondary)",
        "ink-faint": "var(--ink-faint)",
        "pink": "var(--pink)",
        "pink-strong": "var(--pink-strong)",
        "pink-hover": "var(--pink-hover)",
        "on-pink": "var(--on-pink)",
        "purple": "var(--purple)",
        "lavender": "var(--lavender)",
        "lavender-strong": "var(--lavender-strong)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Halftone" design system in ./halftone.
1. Read halftone/README.md (brand book), then halftone/tokens.json, then components/<Name>/README.md for every component you use.
2. Link halftone/tokens.css, halftone/components/bundle.css and halftone/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix ht- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from halftone/assets. For any new picture follow halftone/imagery.md (it has a prompt and a negative prompt).
5. Follow halftone/motion.md and honour prefers-reduced-motion. Check halftone/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Halftone.initExtras()` after the markup exists (again after you add markup later).
