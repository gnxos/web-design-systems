# Install Cirrus

Free during launch. Fonts load from Google Fonts: Inter Tight, JetBrains Mono.

## 1. Add the folder
Copy the `cirrus/` folder into your project (for example `public/cirrus/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="cirrus/tokens.css">
  <link rel="stylesheet" href="cirrus/components/bundle.css">
  <script defer src="cirrus/components/bundle.js"></script>
</head>
<body>
  <a class="cr-btn" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Cirrus.init(); Cirrus.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Cirrus.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `cr-`. Open `cirrus/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./cirrus/tokens.css";
import "./cirrus/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./cirrus/components/bundle.js").then(() => { window.Cirrus?.init?.(); window.Cirrus?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="cr-btn" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "surface": "var(--surface)",
        "surface-container": "var(--surface-container)",
        "surface-container-high": "var(--surface-container-high)",
        "surface-container-higher": "var(--surface-container-higher)",
        "on-surface": "var(--on-surface)",
        "on-surface-variant": "var(--on-surface-variant)",
        "tab-muted": "var(--tab-muted)",
        "tab-muted-safe": "var(--tab-muted-safe)",
        "outline-hairline": "var(--outline-hairline)",
        "outline-strong": "var(--outline-strong)",
        "primary": "var(--primary)",
        "on-primary": "var(--on-primary)",
        "primary-hover": "var(--primary-hover)",
        "primary-hover-safe": "var(--primary-hover-safe)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Cirrus" design system in ./cirrus.
1. Read cirrus/README.md (brand book), then cirrus/tokens.json, then components/<Name>/README.md for every component you use.
2. Link cirrus/tokens.css, cirrus/components/bundle.css and cirrus/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix cr- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from cirrus/assets. For any new picture follow cirrus/imagery.md (it has a prompt and a negative prompt).
5. Follow cirrus/motion.md and honour prefers-reduced-motion. Check cirrus/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Cirrus.initExtras()` after the markup exists (again after you add markup later).
