# Install Draftline

Free during launch. Fonts load from Google Fonts: Geist, Spline Sans Mono.

## 1. Add the folder
Copy the `draftline/` folder into your project (for example `public/draftline/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="draftline/tokens.css">
  <link rel="stylesheet" href="draftline/components/bundle.css">
  <script defer src="draftline/components/bundle.js"></script>
</head>
<body>
  <a class="df-btn df-corners" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Draftline.init(); Draftline.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Draftline.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `df-`. Open `draftline/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./draftline/tokens.css";
import "./draftline/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./draftline/components/bundle.js").then(() => { window.Draftline?.init?.(); window.Draftline?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="df-btn df-corners" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "surface": "var(--surface)",
        "surface-raised": "var(--surface-raised)",
        "surface-sunk": "var(--surface-sunk)",
        "fill-quiet-hover": "var(--fill-quiet-hover)",
        "hairline": "var(--hairline)",
        "drawing": "var(--drawing)",
        "outline-strong": "var(--outline-strong)",
        "on-surface": "var(--on-surface)",
        "on-surface-variant": "var(--on-surface-variant)",
        "on-surface-muted": "var(--on-surface-muted)",
        "on-surface-muted-safe": "var(--on-surface-muted-safe)",
        "primary": "var(--primary)",
        "primary-hover": "var(--primary-hover)",
        "on-primary": "var(--on-primary)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Draftline" design system in ./draftline.
1. Read draftline/README.md (brand book), then draftline/tokens.json, then components/<Name>/README.md for every component you use.
2. Link draftline/tokens.css, draftline/components/bundle.css and draftline/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix df- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from draftline/assets. For any new picture follow draftline/imagery.md (it has a prompt and a negative prompt).
5. Follow draftline/motion.md and honour prefers-reduced-motion. Check draftline/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Draftline.initExtras()` after the markup exists (again after you add markup later).
