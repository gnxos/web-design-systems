/* @ds-bundle: {"format":4,"namespace":"Inkwell","components":[{"name":"Button"},{"name":"SectionBlock"},{"name":"FeatureCard"},{"name":"ProductCard"},{"name":"Scribble"},{"name":"Highlight"},{"name":"Stat"},{"name":"AskBar"},{"name":"Doodles"},{"name":"Confetti"}]} */
(function () {
  "use strict";
  var DOODLES = {"sparkle-outline": {"title": "Four-point sparkle, outline", "w": 100, "h": 100, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" width=\"100\" height=\"100\" role=\"img\" aria-label=\"Four-point sparkle, outline\"><title>Four-point sparkle, outline</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.2\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M50 4 C59.2 35.3 64.7 40.8 96 50 C64.7 59.2 59.2 64.7 50 96 C40.8 64.7 35.3 59.2 4 50 C35.3 40.8 40.8 35.3 50 4Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.1\"/></g></svg>"}, "sparkle-powder": {"title": "Four-point sparkle, powder fill", "w": 100, "h": 100, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" width=\"100\" height=\"100\" role=\"img\" aria-label=\"Four-point sparkle, powder fill\"><title>Four-point sparkle, powder fill</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.2\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M50 4 C59.2 35.3 64.7 40.8 96 50 C64.7 59.2 59.2 64.7 50 96 C40.8 64.7 35.3 59.2 4 50 C35.3 40.8 40.8 35.3 50 4Z\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1.1\"/></g></svg>"}, "hexagon": {"title": "Hexagon outline", "w": 60, "h": 60, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 60 60\" width=\"60\" height=\"60\" role=\"img\" aria-label=\"Hexagon outline\"><title>Hexagon outline</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"0.9\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><polygon points=\"53,33.2 39,52.4 15.5,48.6 5.9,26.6 20.9,7.4 44,12.1\" fill=\"#dfecf1\" stroke=\"#000000\" stroke-width=\"1.0\"/></g></svg>"}, "squircle-ink": {"title": "Solid ink squircle", "w": 60, "h": 60, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 60 60\" width=\"60\" height=\"60\" role=\"img\" aria-label=\"Solid ink squircle\"><title>Solid ink squircle</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M30 8 C50.2 8 52 9.8 52 30 C52 50.2 50.2 52.4 30 52.4 C9.8 52 7.1 50.2 7.1 30 C8 9.8 9.8 8 30 8Z\" fill=\"#000000\" stroke=\"#000000\" stroke-width=\"1.0\" transform=\"rotate(-12 30 30)\"/></g></svg>"}, "squircle-paper": {"title": "Paper squircle with ink outline", "w": 60, "h": 60, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 60 60\" width=\"60\" height=\"60\" role=\"img\" aria-label=\"Paper squircle with ink outline\"><title>Paper squircle with ink outline</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M30 8 C50.2 8 52 9.8 52 30 C52 50.2 50.2 52.4 30 52.4 C9.8 52 7.1 50.2 7.1 30 C8 9.8 9.8 8 30 8Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.4\" transform=\"rotate(10 30 30)\"/></g></svg>"}, "burst": {"title": "Spiky burst backdrop", "w": 240, "h": 240, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 240 240\" width=\"240\" height=\"240\" role=\"img\" aria-label=\"Spiky burst backdrop\"><title>Spiky burst backdrop</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"2.2\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M227.1 119.4 Q212.1 137.4 218.4 159.5 Q200 166.1 204.7 186 Q180.8 183.6 181.6 206.9 Q155.6 199.4 145.3 226.7 Q129 207.2 116.5 224.1 Q102.8 203.5 80.9 222.7 Q70.8 198.9 49.7 192.9 Q47.2 171.1 18.9 167.4 Q30.2 147.3 13.5 135.8 Q31.3 121.4 19.8 107.5 Q29.5 90.8 30.9 71.4 Q45.1 63.5 47.1 46.5 Q70.7 51.4 72 25.5 Q96.3 36.5 110.1 10.2 Q127.4 25.8 146.7 15.4 Q156.1 37.9 179.2 29.4 Q184.1 49.5 201.7 55.8 Q199.6 80.4 227.9 90 Q204.4 108 227.1 119.4Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.0\"/></g></svg>"}, "donut": {"title": "Donut chart doodle", "w": 124, "h": 124, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 124 124\" width=\"124\" height=\"124\" role=\"img\" aria-label=\"Donut chart doodle\"><title>Donut chart doodle</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.4\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"64\" cy=\"63\" r=\"52\" fill=\"#000000\"/><circle cx=\"60\" cy=\"60\" r=\"52\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><path d=\"M60 8 A52 52 0 0 1 105 34 L79.1 49 A22 22 0 0 0 60 38Z\" fill=\"#e6e6e6\" stroke=\"#000000\" stroke-width=\"0.9\"/><path d=\"M105 34 A52 52 0 0 1 108.9 77.8 L80.7 67.5 A22 22 0 0 0 79.1 49Z\" fill=\"#8e8e8e\" stroke=\"#000000\" stroke-width=\"0.9\"/><path d=\"M108.9 77.8 A52 52 0 0 1 77.8 108.9 L67.5 80.7 A22 22 0 0 0 80.7 67.5Z\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"0.9\"/><path d=\"M77.8 108.9 A52 52 0 0 1 51 111.2 L56.2 81.7 A22 22 0 0 0 67.5 80.7Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"0.9\"/><path d=\"M51 111.2 A52 52 0 0 1 60 8 L60 38 A22 22 0 0 0 56.2 81.7Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"0.9\"/><circle cx=\"62\" cy=\"61\" r=\"22\" fill=\"#000000\"/><circle cx=\"60\" cy=\"60\" r=\"21\" fill=\"#dfecf1\" stroke=\"#000000\" stroke-width=\"1\"/><path d=\"M18 74 C24 92 40 104 58 106\" fill=\"none\" stroke=\"#000\" stroke-width=\"0.5\"/><path d=\"M14 66 C17 80 24 90 33 97\" fill=\"none\" stroke=\"#000\" stroke-width=\"0.5\"/></g></svg>"}, "bar-card": {"title": "Tilted bar-chart card", "w": 124, "h": 116, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 124 116\" width=\"124\" height=\"116\" role=\"img\" aria-label=\"Tilted bar-chart card\"><title>Tilted bar-chart card</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.2\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><g transform=\"rotate(-9 60 55)\"><rect x=\"12\" y=\"10\" width=\"100\" height=\"92\" rx=\"2\" fill=\"#000000\"/><rect x=\"8\" y=\"6\" width=\"100\" height=\"92\" rx=\"2\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"20\" y=\"15\" width=\"30\" height=\"5\" fill=\"#000000\"/><rect x=\"22\" y=\"33\" width=\"50\" height=\"11\" fill=\"#000000\"/><rect x=\"20\" y=\"30\" width=\"46\" height=\"11\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"40.7\" y=\"30\" width=\"25.3\" height=\"11\" fill=\"#000000\"/><rect x=\"22\" y=\"55\" width=\"82\" height=\"11\" fill=\"#000000\"/><rect x=\"20\" y=\"52\" width=\"78\" height=\"11\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"55.1\" y=\"52\" width=\"42.9\" height=\"11\" fill=\"#000000\"/><rect x=\"22\" y=\"77\" width=\"66\" height=\"11\" fill=\"#000000\"/><rect x=\"20\" y=\"74\" width=\"62\" height=\"11\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"47.9\" y=\"74\" width=\"34.1\" height=\"11\" fill=\"#000000\"/></g></g></svg>"}, "line-chart-card": {"title": "Line-chart card", "w": 156, "h": 108, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 156 108\" width=\"156\" height=\"108\" role=\"img\" aria-label=\"Line-chart card\"><title>Line-chart card</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.2\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><rect x=\"10\" y=\"10\" width=\"140\" height=\"92\" rx=\"3\" fill=\"#000000\"/><rect x=\"6\" y=\"6\" width=\"140\" height=\"92\" rx=\"3\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"16\" y=\"15\" width=\"56\" height=\"6\" fill=\"#000000\"/><circle cx=\"20\" cy=\"30\" r=\"2.2\" fill=\"#000000\"/><rect x=\"25\" y=\"28.5\" width=\"16\" height=\"3\" fill=\"#000000\"/><circle cx=\"52\" cy=\"30\" r=\"2.2\" fill=\"#bfd9e3\" stroke=\"#000\" stroke-width=\"0.6\"/><rect x=\"57\" y=\"28.5\" width=\"16\" height=\"3\" fill=\"#000000\"/><path d=\"M18 82 C34 50 50 76 66 60 S96 40 112 62 S130 56 136 46 L136 88 L18 88Z\" fill=\"#dfecf1\" stroke=\"none\"/><path d=\"M18 82 C34 50 50 76 66 60 S96 40 112 62 S130 56 136 46\" fill=\"none\" stroke=\"#000000\" stroke-width=\"1.2\"/><path d=\"M18 74 C38 70 52 52 70 72 S104 66 136 70\" fill=\"none\" stroke=\"#000000\" stroke-width=\"0.6\" stroke-dasharray=\"3 3\"/><circle cx=\"18\" cy=\"82\" r=\"3\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><circle cx=\"66\" cy=\"60\" r=\"3\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><circle cx=\"112\" cy=\"62\" r=\"3\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><circle cx=\"136\" cy=\"46\" r=\"3\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><line x1=\"16\" y1=\"88\" x2=\"138\" y2=\"88\" stroke=\"#000000\" stroke-width=\"0.8\"/></g></svg>"}, "scribble-ellipse-paper": {"title": "Hand-drawn ellipse, paper ink", "w": 400, "h": 124, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 400 124\" width=\"400\" height=\"124\" role=\"img\" aria-label=\"Hand-drawn ellipse, paper ink\"><title>Hand-drawn ellipse, paper ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"2.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M44 74 C40 28 188 8 300 14 C372 18 394 42 390 62 C386 94 282 114 182 112 C82 110 20 94 28 64 C34 40 92 24 156 20\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3.3\"/></g></svg>"}, "scribble-underline-paper": {"title": "Hand-drawn underline, paper ink", "w": 310, "h": 34, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 310 34\" width=\"310\" height=\"34\" role=\"img\" aria-label=\"Hand-drawn underline, paper ink\"><title>Hand-drawn underline, paper ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.4\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M8 20 C84 8 204 4 300 9 C236 12 156 17 94 26\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3.3\"/></g></svg>"}, "scribble-ellipse-ink": {"title": "Hand-drawn ellipse, ink ink", "w": 400, "h": 124, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 400 124\" width=\"400\" height=\"124\" role=\"img\" aria-label=\"Hand-drawn ellipse, ink ink\"><title>Hand-drawn ellipse, ink ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"2.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M44 74 C40 28 188 8 300 14 C372 18 394 42 390 62 C386 94 282 114 182 112 C82 110 20 94 28 64 C34 40 92 24 156 20\" fill=\"none\" stroke=\"#000000\" stroke-width=\"3.3\"/></g></svg>"}, "scribble-underline-ink": {"title": "Hand-drawn underline, ink ink", "w": 310, "h": 34, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 310 34\" width=\"310\" height=\"34\" role=\"img\" aria-label=\"Hand-drawn underline, ink ink\"><title>Hand-drawn underline, ink ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.4\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M8 20 C84 8 204 4 300 9 C236 12 156 17 94 26\" fill=\"none\" stroke=\"#000000\" stroke-width=\"3.3\"/></g></svg>"}, "scribble-ellipse-powder": {"title": "Hand-drawn ellipse, powder ink", "w": 400, "h": 124, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 400 124\" width=\"400\" height=\"124\" role=\"img\" aria-label=\"Hand-drawn ellipse, powder ink\"><title>Hand-drawn ellipse, powder ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"2.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M44 74 C40 28 188 8 300 14 C372 18 394 42 390 62 C386 94 282 114 182 112 C82 110 20 94 28 64 C34 40 92 24 156 20\" fill=\"none\" stroke=\"#bfd9e3\" stroke-width=\"3.3\"/></g></svg>"}, "scribble-underline-powder": {"title": "Hand-drawn underline, powder ink", "w": 310, "h": 34, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 310 34\" width=\"310\" height=\"34\" role=\"img\" aria-label=\"Hand-drawn underline, powder ink\"><title>Hand-drawn underline, powder ink</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.4\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M8 20 C84 8 204 4 300 9 C236 12 156 17 94 26\" fill=\"none\" stroke=\"#bfd9e3\" stroke-width=\"3.3\"/></g></svg>"}, "connector": {"title": "Dashed connector with node", "w": 140, "h": 50, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 140 50\" width=\"140\" height=\"50\" role=\"img\" aria-label=\"Dashed connector with node\"><title>Dashed connector with node</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"1.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M10 40 C60 40 70 14 128 14\" fill=\"none\" stroke=\"#000000\" stroke-width=\"1\" stroke-dasharray=\"4 4\"/><path d=\"M120 9 L130 14 L120 19Z\" fill=\"#000000\"/><circle cx=\"10\" cy=\"40\" r=\"4\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1\"/><circle cx=\"70\" cy=\"27\" r=\"2.6\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"0.8\"/></g></svg>"}, "spot-report": {"title": "Spot illustration: report under a magnifier", "w": 300, "h": 270, "svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 300 270\" width=\"300\" height=\"270\" role=\"img\" aria-label=\"Spot illustration: report under a magnifier\"><title>Spot illustration: report under a magnifier</title><defs><filter id=\"ik-r\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"120%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"7\" result=\"n\"/><feDisplacementMap in=\"SourceGraphic\" in2=\"n\" scale=\"2.0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs><g filter=\"url(#ik-r)\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><g transform=\"rotate(7 170 120)\"><rect x=\"118\" y=\"38\" width=\"118\" height=\"150\" fill=\"#000000\"/><rect x=\"113\" y=\"33\" width=\"118\" height=\"150\" fill=\"#f5f5f5\" stroke=\"#000000\" stroke-width=\"1\"/><line x1=\"125\" y1=\"60\" x2=\"215\" y2=\"60\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"69\" x2=\"201\" y2=\"69\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"78\" x2=\"187\" y2=\"78\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"87\" x2=\"215\" y2=\"87\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"96\" x2=\"201\" y2=\"96\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"105\" x2=\"187\" y2=\"105\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"114\" x2=\"215\" y2=\"114\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"123\" x2=\"201\" y2=\"123\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"132\" x2=\"187\" y2=\"132\" stroke=\"#000\" stroke-width=\"0.5\"/><line x1=\"125\" y1=\"141\" x2=\"215\" y2=\"141\" stroke=\"#000\" stroke-width=\"0.5\"/></g><g transform=\"rotate(-4 136 130)\"><rect x=\"78\" y=\"56\" width=\"128\" height=\"160\" fill=\"#000000\"/><rect x=\"72\" y=\"50\" width=\"128\" height=\"160\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.1\"/><rect x=\"84\" y=\"62\" width=\"58\" height=\"8\" fill=\"#000000\"/><rect x=\"84\" y=\"76\" width=\"34\" height=\"3\" fill=\"#000000\"/><rect x=\"91\" y=\"145\" width=\"13\" height=\"34\" fill=\"#000000\"/><rect x=\"88\" y=\"142\" width=\"13\" height=\"34\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"112\" y=\"127\" width=\"13\" height=\"52\" fill=\"#000000\"/><rect x=\"109\" y=\"124\" width=\"13\" height=\"52\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"133\" y=\"153\" width=\"13\" height=\"26\" fill=\"#000000\"/><rect x=\"130\" y=\"150\" width=\"13\" height=\"26\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"154\" y=\"109\" width=\"13\" height=\"70\" fill=\"#000000\"/><rect x=\"151\" y=\"106\" width=\"13\" height=\"70\" fill=\"#dfecf1\" stroke=\"#000000\" stroke-width=\"1\"/><line x1=\"153\" y1=\"110\" x2=\"162\" y2=\"110\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"116\" x2=\"162\" y2=\"116\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"122\" x2=\"162\" y2=\"122\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"128\" x2=\"162\" y2=\"128\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"134\" x2=\"162\" y2=\"134\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"140\" x2=\"162\" y2=\"140\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"146\" x2=\"162\" y2=\"146\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"152\" x2=\"162\" y2=\"152\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"158\" x2=\"162\" y2=\"158\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"164\" x2=\"162\" y2=\"164\" stroke=\"#000\" stroke-width=\"0.4\"/><line x1=\"153\" y1=\"170\" x2=\"162\" y2=\"170\" stroke=\"#000\" stroke-width=\"0.4\"/><rect x=\"175\" y=\"135\" width=\"13\" height=\"44\" fill=\"#000000\"/><rect x=\"172\" y=\"132\" width=\"13\" height=\"44\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><line x1=\"84\" y1=\"178\" x2=\"190\" y2=\"178\" stroke=\"#000000\" stroke-width=\"1\"/><rect x=\"84\" y=\"188\" width=\"70\" height=\"3\" fill=\"#000000\"/><rect x=\"84\" y=\"196\" width=\"48\" height=\"3\" fill=\"#000000\"/></g><path d=\"M224 166 L262 204\" stroke=\"#000000\" stroke-width=\"11\"/><path d=\"M224 166 L262 204\" stroke=\"#ffffff\" stroke-width=\"3\" stroke-dasharray=\"1 9\"/><circle cx=\"203\" cy=\"146\" r=\"33\" fill=\"#000000\"/><circle cx=\"200\" cy=\"143\" r=\"32\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.2\"/><circle cx=\"200\" cy=\"143\" r=\"25\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1\"/><path d=\"M184 132 C188 124 196 120 204 120\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3\"/><path d=\"M186 156 L196 146 L204 152 L216 134\" fill=\"none\" stroke=\"#000000\" stroke-width=\"1.6\"/><path d=\"M52 44 C56.4 59 59 61.6 74 66 C59 70.4 56.4 73 52 88 C47.6 73 45 70.4 30 66 C45 61.6 47.6 59 52 44Z\" fill=\"#bfd9e3\" stroke=\"#000000\" stroke-width=\"1.0\"/><path d=\"M262 38 C264.8 47.5 266.5 49.2 276 52 C266.5 54.8 264.8 56.5 262 66 C259.2 56.5 257.5 54.8 248 52 C257.5 49.2 259.2 47.5 262 38Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"1.0\"/><path d=\"M36 111 C37.8 117.1 38.9 118.2 45 120 C38.9 121.8 37.8 122.9 36 129 C34.2 122.9 33.1 121.8 27 120 C33.1 118.2 34.2 117.1 36 111Z\" fill=\"#000000\" stroke=\"#000000\" stroke-width=\"0.8\"/><path d=\"M276 104 C277.6 109.4 278.6 110.4 284 112 C278.6 113.6 277.6 114.6 276 120 C274.4 114.6 273.4 113.6 268 112 C273.4 110.4 274.4 109.4 276 104Z\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"0.8\"/><polygon points=\"53,197.3 47.5,204.6 38.3,203.3 34.6,194.7 40.5,187.4 49.8,188.5\" fill=\"#dfecf1\" stroke=\"#000000\" stroke-width=\"0.9\"/><path d=\"M254 232 C259.5 232 260 232.5 260 238 C260 243.5 259.5 244.1 254 244.1 C248.5 244 247.8 243.5 247.8 238 C248 232.5 248.5 232 254 232Z\" fill=\"#000000\" stroke=\"#000000\" stroke-width=\"0.8\" transform=\"rotate(-12 254 238)\"/><path d=\"M58 210 C40 224 30 236 20 252\" fill=\"none\" stroke=\"#000000\" stroke-width=\"0.8\" stroke-dasharray=\"3 4\"/><circle cx=\"20\" cy=\"252\" r=\"3.5\" fill=\"#ffffff\" stroke=\"#000000\" stroke-width=\"0.9\"/></g></svg>"}};
  var PATHS = {
    ellipse: "M44 74 C40 28 188 8 300 14 C372 18 394 42 390 62 C386 94 282 114 182 112 C82 110 20 94 28 64 C34 40 92 24 156 20",
    underline: "M8 20 C84 8 204 4 300 9 C236 12 156 17 94 26"
  };
  var VIEWBOX = { ellipse: "0 0 400 124", underline: "0 0 310 34" };
  var NS = "http://www.w3.org/2000/svg";

  function reduced() {
    return !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }

  /* One shared roughness filter for HTML elements (the highlight box border). */
  function ensureFilter(doc) {
    doc = doc || document;
    if (doc.getElementById("ik-rough")) return;
    var svg = doc.createElementNS(NS, "svg");
    svg.setAttribute("width", "0"); svg.setAttribute("height", "0");
    svg.setAttribute("aria-hidden", "true");
    svg.style.position = "absolute";
    svg.innerHTML = '<filter id="ik-rough"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.4" xChannelSelector="R" yChannelSelector="G"/></filter>';
    (doc.body || doc.documentElement).appendChild(svg);
  }

  /* Returns an element holding the named doodle as inline SVG. */
  function doodle(name, opts) {
    opts = opts || {};
    var d = DOODLES[name];
    if (!d) throw new Error("Inkwell: unknown doodle " + name + ". Known: " + Object.keys(DOODLES).join(", "));
    var el = document.createElement("span");
    el.className = "ik-doodle" + (opts.motion ? " ik-" + opts.motion : "") + (opts.className ? " " + opts.className : "");
    el.style.width = (opts.size || d.w) + "px";
    el.innerHTML = d.svg;
    if (opts.delay) el.style.animationDelay = opts.delay + "ms";
    return el;
  }

  /* Wrap text in a hand-drawn ellipse or underline that draws itself on when visible. */
  function scribble(target, opts) {
    opts = opts || {};
    var kind = opts.kind || target.getAttribute("data-ik-scribble") || "ellipse";
    if (!PATHS[kind]) kind = "ellipse";
    if (target.querySelector(":scope > svg")) return target;
    target.classList.add("ik-scribble", "ik-scribble--" + kind);
    if (opts.ink) target.classList.add("ik-scribble--" + opts.ink);
    var svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", VIEWBOX[kind]);
    svg.setAttribute("preserveAspectRatio", "none");
    svg.setAttribute("aria-hidden", "true");
    var p = document.createElementNS(NS, "path");
    p.setAttribute("d", PATHS[kind]);
    p.setAttribute("pathLength", "1");
    svg.appendChild(p);
    target.appendChild(svg);
    if (reduced() || opts.animate === false || !("IntersectionObserver" in window)) {
      target.setAttribute("data-static", "");
      return target;
    }
    target.classList.add("is-pending");
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          setTimeout(function () { target.classList.add("is-drawn"); target.classList.remove("is-pending"); }, opts.delay || 250);
          io.disconnect();
        }
      });
    }, { threshold: 0.6 });
    io.observe(target);
    return target;
  }

  /* Seeded scatter of small doodles around the edges of a block (hero confetti). */
  function confetti(container, opts) {
    opts = opts || {};
    var seed = opts.seed || 7;
    function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
    var kit = opts.kit || ["hexagon", "squircle-ink", "squircle-paper", "sparkle-outline", "sparkle-powder", "hexagon", "squircle-paper", "squircle-ink"];
    var count = opts.count || 12;
    var layer = document.createElement("div");
    layer.className = "ik-confetti";
    layer.setAttribute("aria-hidden", "true");
    for (var i = 0; i < count; i++) {
      var name = kit[i % kit.length];
      var big = /sparkle/.test(name);
      var size = Math.round((big ? 34 : 22) + rnd() * (big ? 26 : 14));
      var x, y, tries = 0;
      do { x = rnd() * 94 + 1; y = rnd() * 88 + 4; tries++; } while (x > 15 && x < 85 && tries < 40);
      var motion = big ? "twinkle" : (rnd() < 0.7 ? "spin" : "bob");
      var el = doodle(name, { size: size, motion: reduced() ? null : motion, delay: Math.round(rnd() * -9000) });
      el.style.left = x + "%"; el.style.top = y + "%";
      el.style.transform = "rotate(" + Math.round(rnd() * 40 - 20) + "deg)";
      layer.appendChild(el);
    }
    container.insertBefore(layer, container.firstChild);
    return layer;
  }

  /* Fallback for browsers without scroll-driven animations. */
  function rise(root) {
    if (window.CSS && CSS.supports && CSS.supports("animation-timeline: view()")) return;
    var els = (root || document).querySelectorAll(".ik-rise");
    if (!("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("is-in"); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-in"); io.unobserve(e.target); } });
    }, { threshold: 0.15 });
    els.forEach(function (e) { io.observe(e); });
  }

  /* Wire everything declared with data attributes. Safe to call more than once. */
  function init(root) {
    root = root || document;
    ensureFilter(root.ownerDocument || root);
    root.querySelectorAll("[data-ik-scribble]").forEach(function (el) {
      scribble(el, { kind: el.getAttribute("data-ik-scribble"), ink: el.getAttribute("data-ik-ink") || undefined });
    });
    root.querySelectorAll("[data-ik-doodle]").forEach(function (el) {
      if (el.firstChild) return;
      var d = doodle(el.getAttribute("data-ik-doodle"), { size: +el.getAttribute("data-size") || undefined, motion: reduced() ? null : el.getAttribute("data-motion") });
      var css = el.getAttribute("style"); if (css) d.setAttribute("style", (d.getAttribute("style") || "") + ";" + css);
      if (el.className) d.className += " " + el.className;
      el.replaceWith(d);
    });
    root.querySelectorAll("[data-ik-confetti]").forEach(function (el) {
      if (el.querySelector(":scope > .ik-confetti")) return;
      confetti(el, { count: +el.getAttribute("data-ik-confetti") || 12, seed: +el.getAttribute("data-seed") || 7 });
    });
    rise(root);
  }

  window.Inkwell = {
    version: "1.0.0",
    doodles: DOODLES,
    names: Object.keys(DOODLES),
    doodle: doodle,
    scribble: scribble,
    confetti: confetti,
    rise: rise,
    init: init,
    ensureFilter: ensureFilter
  };
})();

/* Shared component extras */
(function () {
  var NS = window.Inkwell; if (!NS) return; var P = "ik";
  function select(root) {
    var btn = root.querySelector("." + P + "-select__btn"), opts = [].slice.call(root.querySelectorAll("." + P + "-select__opt")), idx = -1, val = root.querySelector("[data-value]");
    function open(o) { root.classList.toggle("is-open", o); btn.setAttribute("aria-expanded", o ? "true" : "false"); if (!o) { idx = -1; opts.forEach(function (x) { x.classList.remove("is-focused"); }); } }
    function focus(n) { idx = (n + opts.length) % opts.length; opts.forEach(function (x, k) { x.classList.toggle("is-focused", k === idx); }); }
    btn.addEventListener("click", function () { open(!root.classList.contains("is-open")); });
    root.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { open(false); btn.focus(); }
      else if (e.key === "ArrowDown") { e.preventDefault(); open(true); focus(idx + 1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); open(true); focus(idx - 1); }
      else if (e.key === "Enter" && idx > -1) { e.preventDefault(); opts[idx].click(); }
    });
    opts.forEach(function (o) { o.addEventListener("click", function () { opts.forEach(function (x) { x.setAttribute("aria-selected", x === o ? "true" : "false"); }); if (val) val.textContent = o.textContent; open(false); btn.focus(); }); });
    document.addEventListener("click", function (e) { if (!root.contains(e.target)) open(false); });
  }
  function tabset(root) {
    var tabs = [].slice.call(root.querySelectorAll('[role="tab"]'));
    function show(t) { tabs.forEach(function (x) { var on = x === t; x.setAttribute("aria-selected", on ? "true" : "false"); x.tabIndex = on ? 0 : -1; var pn = document.getElementById(x.getAttribute("aria-controls")); if (pn) pn.hidden = !on; }); t.focus(); }
    tabs.forEach(function (t, i) { t.addEventListener("click", function () { show(t); }); t.addEventListener("keydown", function (e) { if (e.key === "ArrowRight") { e.preventDefault(); show(tabs[(i + 1) % tabs.length]); } if (e.key === "ArrowLeft") { e.preventDefault(); show(tabs[(i - 1 + tabs.length) % tabs.length]); } }); });
  }
  NS.select = select; NS.tabset = tabset;
  NS.initExtras = function (r) {
    r = r || document;
    [].forEach.call(r.querySelectorAll("." + P + "-select"), select);
    [].forEach.call(r.querySelectorAll("." + P + "-tabset"), tabset);
    [].forEach.call(r.querySelectorAll("[data-dismiss]"), function (b) { b.addEventListener("click", function () { var t = b.closest("[data-dismissible]"); if (t) t.hidden = true; }); });
  };
})();
