# Install Inkwell

Free during launch. Fonts load from Google Fonts: Archivo.

## 1. Add the folder
Copy the `inkwell/` folder into your project (for example `public/inkwell/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="light">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="inkwell/tokens.css">
  <link rel="stylesheet" href="inkwell/components/bundle.css">
  <script defer src="inkwell/components/bundle.js"></script>
</head>
<body>
  <a class="ik-btn ik-btn--lg ik-btn--primary" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Inkwell.init(); Inkwell.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Inkwell.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `ik-`. Open `inkwell/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./inkwell/tokens.css";
import "./inkwell/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="light">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./inkwell/components/bundle.js").then(() => { window.Inkwell?.init?.(); window.Inkwell?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="ik-btn ik-btn--lg ik-btn--primary" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "surface": "var(--surface)",
        "surface-fog": "var(--surface-fog)",
        "powder": "var(--powder)",
        "powder-50": "var(--powder-50)",
        "ink": "var(--ink)",
        "on-powder": "var(--on-powder)",
        "muted": "var(--muted)",
        "line": "var(--line)",
        "line-strong": "var(--line-strong)",
        "focus": "var(--focus)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Inkwell" design system in ./inkwell.
1. Read inkwell/README.md (brand book), then inkwell/tokens.json, then components/<Name>/README.md for every component you use.
2. Link inkwell/tokens.css, inkwell/components/bundle.css and inkwell/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix ik- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from inkwell/assets. For any new picture follow inkwell/imagery.md (it has a prompt and a negative prompt).
5. Follow inkwell/motion.md and honour prefers-reduced-motion. Check inkwell/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Inkwell.initExtras()` after the markup exists (again after you add markup later).
