# Install Afterglow

Free during launch. Fonts load from Google Fonts: Geist, Geist Mono.

## 1. Add the folder
Copy the `afterglow/` folder into your project (for example `public/afterglow/` or next to your HTML).

## 2. Link it (plain HTML)
```html
<!doctype html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="afterglow/tokens.css">
  <link rel="stylesheet" href="afterglow/components/bundle.css">
  <script defer src="afterglow/components/bundle.js"></script>
</head>
<body>
  <a class="ag-btn ag-btn--primary" href="#">Get started</a>
  <script>window.addEventListener("DOMContentLoaded", function () { Afterglow.init(); Afterglow.initExtras(); });</script>
</body>
</html>
```
Switch theme with `Afterglow.theme` where available, or set `data-theme` on `<html>` (themes: see tokens.json `color.themes`).

## 3. Build with the components
Every component has `components/<Name>/preview.html` (a live example, copy its markup) and `README.md` (what it needs).
All classes start with `ag-`. Open `afterglow/index.html` in a browser to see all of them in light and dark.

## 4. React / Next.js
```jsx
import "./afterglow/tokens.css";
import "./afterglow/components/bundle.css";
// app/layout.jsx: <html lang="en" data-theme="dark">
// a client component for behaviours (tabs, dropdowns, hero effects):
"use client";
import { useEffect } from "react";
export default function Behaviours() {
  useEffect(() => { import("./afterglow/components/bundle.js").then(() => { window.Afterglow?.init?.(); window.Afterglow?.initExtras?.(); }); }, []);
  return null;
}
export const Cta = () => <a className="ag-btn ag-btn--primary" href="#">Get started</a>;
```

## 5. Tailwind
```js
// tailwind.config.js
module.exports = {
  theme: { extend: {
    colors: {
        "canvas": "var(--canvas)",
        "panel": "var(--panel)",
        "raised": "var(--raised)",
        "ground": "var(--ground)",
        "ink": "var(--ink)",
        "muted": "var(--muted)",
        "faint": "var(--faint)",
        "border": "var(--border)",
        "border-strong": "var(--border-strong)",
        "hover": "var(--hover)",
        "active": "var(--active)",
        "selected": "var(--selected)",
        "signal": "var(--signal)",
        "signal-ink": "var(--signal-ink)"
    },
    fontFamily: { sans: ["var(--font-sans)"], mono: ["var(--font-mono)"] }
  } }
};
```
Keep `tokens.css` linked so the variables exist, and dark mode follows `data-theme`.

## 6. With an AI coding agent
Paste this into the agent:
```
Build the UI with the "Afterglow" design system in ./afterglow.
1. Read afterglow/README.md (brand book), then afterglow/tokens.json, then components/<Name>/README.md for every component you use.
2. Link afterglow/tokens.css, afterglow/components/bundle.css and afterglow/components/bundle.js. Set data-theme on <html>.
3. Use the class prefix ag- and the tokens (var(--token)). Never hard-code colours, radii, shadows or timings.
4. Take images from afterglow/assets. For any new picture follow afterglow/imagery.md (it has a prompt and a negative prompt).
5. Follow afterglow/motion.md and honour prefers-reduced-motion. Check afterglow/accessibility.md flags before using a flagged colour.
```

## 7. Troubleshooting
- Unstyled page: check the three paths above, and open over http (`python3 -m http.server`) if file:// blocks fonts.
- Wrong fonts: tokens.css imports them from Google Fonts; allow fonts.googleapis.com and fonts.gstatic.com.
- Nothing happens on tabs or menus: call `Afterglow.initExtras()` after the markup exists (again after you add markup later).
